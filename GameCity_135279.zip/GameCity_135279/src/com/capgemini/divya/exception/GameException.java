package com.capgemini.divya.exception;

public class GameException extends Exception
{
	private static final long serialVersionUID = -5649970975683986932L;

	public GameException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GameException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public GameException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public GameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public GameException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
